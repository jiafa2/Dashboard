import React  from "react";
import Login from "./Login/Login";


const App = () =>{
     return(
       <>
          <Login/>
       </>   
     );
 }

export default App;