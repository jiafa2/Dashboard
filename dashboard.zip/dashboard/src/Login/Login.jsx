import React from 'react'
import bgImg from "../images/Login.png";

export default function Login() {
    return (
        <div>
            <div className="container-fluid">
                <div className="row">
                    <div className="col-lg-6"  style={{padding:"0"}}>
                       <img className="LoginImg" src={bgImg}/>
                    </div>
                    <div className="col-lg-6 text-center"  style={{padding:"0"}}>
                   
                       <div className="loginContent">  
                         <br/>
                         <form>
                         <h3 className="loginHeading d-flex flex-row">Login</h3>
                            <input type="email" id="inputPassword5" class="form-control" placeholder="Username"/>
                            <input type="password" id="inputPassword5" class="form-control" placeholder="Password"/>
                            
                            <div style={{display: "flex",justifyContent:'space-between',marginBottom:'3%'}}>
                            <button type="submit" className="btn btn-primary" style={{justifyContent:"start",padding:'2% 7%',fontWeight:'bold'}}>Login</button>
                            <a href="#"  style={{justifyContent:"end",color:'#5D6C97',textDecoration:'none'}}>Forget Password?</a>
                            </div>
                          
                        </form>
                       </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
